<?php 
include('../include/config.php');

$obj = new db_class();

?>

<!DOCTYPE html>
<html lang="en">
    <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo TITLE;?></title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,600,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,500,600,900" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo BASE_URL ?>css/bootstrap.min.css?v=<?php echo rand(1000,10000); ?>" media="all">
    <link rel="stylesheet" href="<?php echo BASE_URL ?>css/all.min.css?v=<?php echo rand(100,1000); ?>" media="all">
    <link rel="stylesheet" href="<?php echo BASE_URL ?>css/owl.carousel.min.css?v=<?php echo rand(100000,1000000); ?>" media="all">
    <link rel="stylesheet" href="<?php echo BASE_URL ?>css/tp-animation.css?v=<?php echo rand(10,100); ?>" media="all">
    <link rel="stylesheet" href="<?php echo BASE_URL ?>css/style.css?v=<?php echo rand(100000,1000000); ?>" media="all">
    <link rel="stylesheet" href="<?php echo BASE_URL ?>css/responsive.css?v=<?php echo rand(1000,10000); ?>" media="all">    
</head>
<style>
    body  {
        background-image: url("http://localhost/narendra/Swachh_Bhopal_Competitions/images/background.png");
        background-repeat: no-repeat;
        }
</style>
<body>
    <header class="tp-main-menu header-menu-1 sticky-header">
        <!-- top logo/contac inf -->
        <div class="container">
            <div class="row row_menu_1">
                <div class="col-lg-6 col-md-6 col-12 col-logo-3">
                  
                </div>
                <div class="col-lg-6 col-md-6 col-12">
                    <nav class="tp-menu tagpoint-menu-2">
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <img src="<?php echo BASE_URL; ?>/images/1.png">
    <section class="dropex-section faq-section" style="padding-top: 2em;">
            <div class="row">
                <div class="col-lg-5 col-md-12 col-12" style="padding-top: 4em;">
                    <div class="section-head">
                        <img src="<?php echo BASE_URL ?>images/Swachh_Pratispardha_1.png" class="img-responsive">
                    </div> 
                </div>
				<div class="col-lg-7 col-md-12 col-12">
                    <div class="wrap_callbak">
                       <div class="row">
                            <div class="col-sm-4">&nbsp;</div>
                            <div class="col-sm-4"><?php if(isset($msg)){echo $msg;}?></div>
                            <div class="col-sm-4">&nbsp;</div>
                        </div>
                  <p style="
    font-size: 1.5em;
    font-weight: 700;
    line-height: 2em;
    text-align: justify;
">नगर पालिक निगम भोपाल द्वारा स्वच्छ सर्वेक्षण 2023 हेतु नगर निगम सीमान्तर्गत रहवासी संघ, होटल, हॉस्पिटल, मार्केट, ऑफिस, बाजार अलग अलग श्रेणी में निर्धारित माप दण्डों के आधार पर प्रतिस्पर्धा आयोजित की जा रही है। 
जिसमे प्रतिभागी गूगल फॉर्म लिंक के माध्यम से आवेदन कर हिस्सा ले सकते </p>
<p style="
    font-size: 1.5em;
    font-weight: 600;
">स्वच्छ रहवासी संघ/मोहल्ला/वार्ड पुरूस्कार 2023 &nbsp;<span class="blink" style="
    font-size: 0.6em;
    color: #69a3c7;
    font-weight: 700;
"><a href="https://docs.google.com/forms/d/15HPlqrz-9DXpzGcsiVWxdHUXWxJ_Qnk9yWnopAAf9vk/" target="_blank" style="
    color: blue;
">click</a></span></p>
<p style="
    font-size: 1.5em;
    font-weight: 600;
">स्वच्छ बाजार पुरस्कार-2023 &nbsp;<span style="
    font-size: 0.6em;
    color: #69a3c7;
    font-weight: 700;
"><a href="https://docs.google.com/forms/d/1cozJDVsTgb3XUkUXz5txijdPc2tPXP16pxqHLlN2f_w/" target="_blank" style="
    color: blue;
">click</a></span></p>
<p style="
    font-size: 1.5em;
    font-weight: 600;
">स्वच्छ ऑफिस पुरूस्कार-2023 &nbsp;<span style="
    font-size: 0.6em;
    color: #69a3c7;
    font-weight: 700;
"><a href="https://docs.google.com/forms/d/1tLDUhQCa01uyilN7ypsS7hjI6b2iq2jDvr-ZPjq78Rg/" target="_blank" style="
    color: blue;
">click</a></span></p>
<p style="
    font-size: 1.5em;
    font-weight: 600;
">स्वच्छ अस्पताल/नर्सिंग होम पुरूस्कार-2023 &nbsp;<span style="
    font-size: 0.6em;
    color: #69a3c7;
    font-weight: 700;
"><a href="https://docs.google.com/forms/d/1_5nRC8dmrCGH2dR-ywrj_m_9ANl_rHVy9l85HOfp9wc/" target="_blank" style="
    color: blue;
">click</a></span></p>
<p style="
    font-size: 1.5em;
    font-weight: 600;
">स्वच्छ विद्यालय पुरूस्कार-2023 &nbsp;<span style="
    font-size: 0.6em;
    color: #69a3c7;
    font-weight: 700;
"><a href="https://docs.google.com/forms/d/10lCB0fPyq7cRd1zkyc1i2up82l5fZSvxqvlf3cmwhq8/" target="_blank" style="
    color: blue;
">click</a></span></p>
<p style="
    font-size: 1.5em;
    font-weight: 600;
">स्वच्छ होटल/रेस्टोरेंट पुरूस्कार-2023 &nbsp;<span style="
    font-size: 0.6em;
    color: #69a3c7;
    font-weight: 700;
"><a href="https://docs.google.com/forms/d/1e3O1qA4oJOhxJKjQzvw5jVr2DEYkhuFtSO4WDbmyvX4/" target="_blank" style="
    color: blue;
">click</a></span></p>
                    </div>
                </div>
            </div>
    </section> 
    <script src="<?php echo BASE_URL ?>js/jquery.min.js"></script>
    <script src="<?php echo BASE_URL ?>js/owl.carousel.min.js"></script>
    <script src="<?php echo BASE_URL ?>js/odometer.min.js"></script>
    <script src="<?php echo BASE_URL ?>js/progressbar.min.js"></script>
    <script src="<?php echo BASE_URL ?>js/masonary.min.js"></script>
    <script src="<?php echo BASE_URL ?>js/multipleFilterMasonry.js"></script>
    <script src="<?php echo BASE_URL ?>js/light-box.js"></script>
    <script src="<?php echo BASE_URL ?>js/noframework.waypoints.min.js"></script>
    <script src="<?php echo BASE_URL ?>js/index.js"></script>
</div>
</body>
</html>